import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Registration } from './reg.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class RegService {
  constructor(
    @InjectRepository(Registration)
    private readonly registrationRepository: Repository<Registration>,
  ) {}

  async register(patientData: Partial<Registration>): Promise<Registration> {
    const { password, ...rest } = patientData;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newRegistration = this.registrationRepository.create({
      ...rest,
      password: hashedPassword,
    });

    return this.registrationRepository.save(newRegistration);
  }

  async validatePatient(
    email: string,
    password: string,
  ): Promise<Registration | null> {
    const registration = await this.registrationRepository.findOne({
      where: { email },
    });

    if (
      registration &&
      (await bcrypt.compare(password, registration.password))
    ) {
      return registration;
    }

    return null;
  }
}
