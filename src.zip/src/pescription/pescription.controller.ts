import { Controller } from '@nestjs/common';

@Controller('pescription')
export class PescriptionController {}
