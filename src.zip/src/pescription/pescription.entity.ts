import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Prescription {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  patientId: number;

  @Column()
  doctorName: string;

  @Column('text')
  prescriptionDetails: string;

  @Column('timestamp', { default: () => 'CURRENT_TIMESTAMP' })
  date: Date;
}
