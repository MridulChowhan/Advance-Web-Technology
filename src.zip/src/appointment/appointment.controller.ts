import { Controller } from '@nestjs/common';

@Controller('appointment')
export class AppointmentController {}
