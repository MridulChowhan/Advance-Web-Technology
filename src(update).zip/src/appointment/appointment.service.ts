import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository } from 'typeorm';
import { Appointment } from './appointment.entity';

@Injectable()
export class AppointmentService {
  constructor(
    @InjectRepository(Appointment)
    private readonly appointmentRepo: Repository<Appointment>,
  ) {}

  async appoint(patientData: Partial<Appointment>): Promise<Appointment> {
    const newAppointment = this.appointmentRepo.create(patientData);
    return this.appointmentRepo.save(newAppointment);
  }

  async deleteAppointment(id: string): Promise<DeleteResult> {
    return this.appointmentRepo.delete(id);
  }

  async getAppointmentById(id: string): Promise<Appointment | null> {
    return this.appointmentRepo.findOne({ where: { id: parseInt(id, 10) } });
  }

  async getAllAppointments(): Promise<Appointment[]> {
    return this.appointmentRepo.find();
  }

  async updateAppointment(
    id: string,
    updateData: Partial<Appointment>,
  ): Promise<Appointment | null> {
    await this.appointmentRepo.update(id, updateData);
    return this.appointmentRepo.findOne({ where: { id: parseInt(id, 10) } });
  }
}
