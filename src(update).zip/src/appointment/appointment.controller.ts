import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
  Delete,
  Param,
  Get,
  Patch,
} from '@nestjs/common';
import { AppointmentService } from './appointment.service';
import { Appointment } from './appointment.entity';


@Controller('appointment')
export class AppointmentController {
  constructor(private readonly appointmentService: AppointmentService) {}

  @Post('appoint')
  async appoint(@Body() patientData: any) {
    try {
      const appointmentPatient =
        await this.appointmentService.appoint(patientData);
      return {
        message: 'Appointment Confirmed',
        data: appointmentPatient,
      };
    } catch (error) {
      console.error('Appointment does not confirmed for', error);
      throw new HttpException(
        'Appointment confirmation failed',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Delete(':id')
  async deleteAppointment(@Param('id') id: string) {
    try {
      const result = await this.appointmentService.deleteAppointment(id);
      if (result.affected === 0) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Appointment deleted successfully',
      };
    } catch (error) {
      console.error('Failed to delete appointment', error);
      throw new HttpException(
        'Failed to delete appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get(':id')
  async getAppointmentById(@Param('id') id: string) {
    try {
      const appointment = await this.appointmentService.getAppointmentById(id);
      if (!appointment) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return appointment;
    } catch (error) {
      console.error('Failed to get appointment by ID', error);
      throw new HttpException(
        'Failed to get appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get()
  async getAllAppointments() {
    try {
      const appointments = await this.appointmentService.getAllAppointments();
      return appointments;
    } catch (error) {
      console.error('Failed to get all appointments', error);
      throw new HttpException(
        'Failed to get appointments',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Patch(':id')
  async updateAppointment(
    @Param('id') id: string,
    @Body() updateData: Partial<Appointment>,
  ) {
    try {
      const updatedAppointment =
        await this.appointmentService.updateAppointment(id, updateData);
      if (!updatedAppointment) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Appointment updated successfully',
        data: updatedAppointment,
      };
    } catch (error) {
      console.error('Failed to update appointment', error);
      throw new HttpException(
        'Failed to update appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
