import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors(); // Enable CORS if accessing from external clients
  await app.listen(3000); // Ensure your port matches the one used in Postman
}
bootstrap();
