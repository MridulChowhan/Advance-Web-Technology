import { Test, TestingModule } from '@nestjs/testing';
import { PescriptionService } from './pescription.service';

describe('PescriptionService', () => {
  let service: PescriptionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PescriptionService],
    }).compile();

    service = module.get<PescriptionService>(PescriptionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
