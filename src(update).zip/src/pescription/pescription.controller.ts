import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { PescriptionService } from './pescription.service';

@Controller('pescription')
export class PescriptionController {
  constructor(private readonly pescriptionService: PescriptionService) {}

  @Post('create')
  async prescription(@Body() patientData: any) {
    try {
      const pescriptionPatient =
        await this.pescriptionService.prescription(patientData);
      return {
        message: 'Prescription created successfully',
        data: pescriptionPatient,
      };
    } catch (error) {
      console.error('Prescription Error:', error);
      throw new HttpException(
        'Prescription creation failed',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Get(':id')
  async getPrescriptionById(@Param('id') id: string) {
    try {
      const prescription =
        await this.pescriptionService.getPrescriptionById(id);
      if (!prescription) {
        throw new HttpException('Prescription not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Prescription retrieved successfully',
        data: prescription,
      };
    } catch (error) {
      console.error('Get Prescription Error:', error);
      throw new HttpException(
        'Failed to retrieve prescription',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  
  @Get()
  async getAllPrescriptions() {
    try {
      const prescriptions = await this.pescriptionService.getAllPrescriptions();
      return {
        message: 'Prescriptions retrieved successfully',
        data: prescriptions,
      };
    } catch (error) {
      console.error('Get All Prescriptions Error:', error);
      throw new HttpException(
        'Failed to retrieve prescriptions',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
}
