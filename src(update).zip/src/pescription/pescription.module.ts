import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PescriptionController } from './pescription.controller';
import { PescriptionService } from './pescription.service';
import { Prescription } from './pescription.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Prescription])],
  controllers: [PescriptionController],
  providers: [PescriptionService],
})
export class PescriptionModule {}
