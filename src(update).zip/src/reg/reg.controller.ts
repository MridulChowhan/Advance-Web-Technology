import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { RegService } from './reg.service';

@Controller('reg')
export class RegController {
  constructor(private readonly regService: RegService) {}

  @Post('register')
  async register(@Body() patientData: any) {
    try {
      const registeredPatient = await this.regService.register(patientData);
      return {
        message: 'Registration successful',
        data: registeredPatient,
      };
    } catch (error) {
      console.error('Registration Error:', error);
      throw new HttpException('Registration failed', HttpStatus.BAD_REQUEST);
    }
  }
  
  @Post('login')
  async login(
    @Body() { email, password }: { email: string; password: string },
  ) {
    const patient = await this.regService.validatePatient(email, password);
    if (!patient) {
      throw new HttpException('Invalid credentials', HttpStatus.UNAUTHORIZED);
    }
    return { message: 'Login successful', patient };
  }
}
