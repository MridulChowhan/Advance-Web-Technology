import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Registration } from './reg.entity';

@Injectable()
export class RegService {
  constructor(
    @InjectRepository(Registration)
    private readonly registrationRepo: Repository<Registration>,
  ) {}

  async register(patientData: Partial<Registration>): Promise<Registration> {
    const newRegistration = this.registrationRepo.create(patientData);
    return this.registrationRepo.save(newRegistration);
  }

  async validatePatient(
    email: string,
    password: string,
  ): Promise<Registration | null> {
    const registration = await this.registrationRepo.findOne({
      where: { email },
    });
    return registration && registration.password === password
      ? registration
      : null;
  }
}
