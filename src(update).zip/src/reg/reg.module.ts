import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RegService } from './reg.service';
import { RegController } from './reg.controller';
import { Registration } from './reg.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Registration])],
  controllers: [RegController],
  providers: [RegService],
})
export class RegModule {}
